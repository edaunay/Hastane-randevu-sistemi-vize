package com.example.hastanerandevu.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hastanerandevu.model.Appointment
import com.example.hastanerandevu.model.Blogs
import com.example.hastanerandevu.model.Policlinic
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.User
import com.example.hastanerandevu.repository.MainRepository
import kotlinx.coroutines.launch

class MainViewModel(application: Application, private val mainRepository: MainRepository): AndroidViewModel(application) {

    fun addHospital(hospital: Hospital) = viewModelScope.launch {
        mainRepository.addHospital(hospital)
    }

    fun getHospital() = mainRepository.getHospital()

    fun addPoliclinic(policlinic: Policlinic) = viewModelScope.launch {
        mainRepository.addPoliclinic(policlinic)
    }

    fun getPoliclinic() = mainRepository.getPoliclinic()

    fun registerUser(user: User) = viewModelScope.launch {
        mainRepository.registerUser(user)
    }

    fun getUser() = mainRepository.getUser()

    fun loginUser(tcNo: Long,password: String) = mainRepository.loginUser(tcNo, password)

    fun addAppointment(appointment: Appointment) = viewModelScope.launch {
        mainRepository.addAppointment(appointment)
    }

    fun myAppointment(tcNo: Long) = mainRepository.myAppointment(tcNo)

    fun addBlogs(blogs: Blogs) = viewModelScope.launch {
        mainRepository.addBlog(blogs)
    }

    fun getBlogs() = mainRepository.getBlogs()


}