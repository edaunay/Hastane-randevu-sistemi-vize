package com.example.hastanerandevu.views

import com.example.hastanerandevu.model.Blogs

object Utils {

    fun getBlogList(): List<Blogs> {
        val blogList = arrayListOf<Blogs>()
        val blog1 = Blogs(
            0,
            "Egzamanın Tanımı",
            "Atopik dermatit diger adiyla egzama çevresel ve genetik faktörlere bagli olarak gelisen kronik bir cilt hastaligidir. Bu hastalarda cildin su tutma\n" +
                    "Özelligi ve bariyer özelliginin kaybolmastyla ciltte kizarikliklar, kuruluklar, kasintilar baslar. Bu da hassaslasan cilde alerjenlerin temasi ile olayin daha da siddetlenmesine, bakterilerin cilde rahatlikla nüfuz etmesi ile cilt enfeksiyonlarina davetive cikarmaktadir.",
            "Cildiye doktoruna gidilmelidir."
        )

        val blog2 = Blogs(
            0,
            "Orta kulak iltihabi neden olur?",
            "Çogu orta kulak enfeksiyonu, soguk alginligi, grip gibi bir enfeksiyon nedeniyle orta kulakta mukus olusmasiyla ortaya çikar. Östaki borusunda (orta kulaktan burnun arkasina do§ru uzanan ince bir tüp) sislik olusmasi sonucu mukus bosaltilamazsa iltihap olusur ve otitis media gelisir.",
            "Kulak burun boğaz doktoruna görünün"
        )

        val blog3 = Blogs(
            0,
            "Aralıklı Oruç Yöntemleri",
            "Aralıklı oruç, genellikle kilo kaybetmek için ugulanan bir beslenme seklidir.\n" +
                    "Aralıklı oruç denilince akla ilk gelen ve en yaygin olan 16/8 (16 saat açlik, 8 saat yemek yeme) beslenme sekli olsa da aslında birçok türü vardır.\n" +
                    "16/8 Yöntemi\n" +
                    "Bu yöntemde günün 8 saatini yemek yiyebileceginiz aralik olarak belirlerken kalan 16 saatini aç kalmak için ayarlamalısınız.\n" +
                    "Aç kalınan sürede su, çay, kahve gibi içecekler tüketilebilir ancak şeker içermemelidir.\n" +
                    "5/2 Yöntemi\n" +
                    "Bu yöntemde ise haftanın herhangi iki gününde kısıtlı (500-600) kalori alınırken diğer 5 günde normal beslenme düzenine devam edilmesi tavsiye edilir.\n" +
                    "Kısıtı kalori alımı için seçilen günler ardışık olmamalıdır.",
            "Diyetisyen doktoruna gidilmeli"
        )

        val blog4 = Blogs(
            0,
            "Siroz Tanımı",
        "• Siroz, uzun süreli karaciger hasarinin neden oldu@u durumlarin karacigerde kalici degisiklik olusturmasidir.\n" +
                "• Karacigerdeki uzun süreli iltihap, karacigerdeki saglikli dokunun yerini alir ve karacigerin düzgün çalismasini engeller.\n" +
                "• Sirozun neden oldugu hasar tersine çevrilemez ve sonunda o kadar genisleyebilir ki karacigeriniz çalismayi durdurabilir. Buna karaciger yetmezligi denir.\n" +
                "• Karaciger islevini vitirirse siroz ölümcül olabilir. Bununla birlikte, durumun bu asamaya ulasmasi genellikle yillar alir ve tedavi, ilerlemesini yavaslatmaya yardimci olabilir.",
        "İç hastalıkları doktorundan randevu alınmalıdır")

        val blog5 = Blogs(
            0,
            "Konjonktivit Tanımı",
            "Konjonktivit, gözün önünü kaplayan ince doku tabakasinin (konjonktiva) kizarikligina ve iltihaplanmasina neden olan yaygin bir durumdur.\n" +
                    "insanlar genellikle konjonktivitten kirmizi göz olarak bahseder.\n" +
                    "Konjonktivitin diger semptomlari arasinda gözlerde kasinti ve sulanma bazen kirpiklerde yapiskan bir kaplama (eger alerjiden kaynaklaniyorsa) bulunur.\n" +
                    "Konjonktivit ilk basta bir gözü etkileyebilir, ancak genellikle birkaç saat sonra her iki gözü de etkiler",
        "Göz doktorundan randevu alınmalıdır")

        blogList.add(blog1)
        blogList.add(blog2)
        blogList.add(blog3)
        blogList.add(blog4)
        blogList.add(blog5)


        return blogList
    }


}