package com.example.hastanerandevu.views.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.ActivityRegisterBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Policlinic
import com.example.hastanerandevu.model.User
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.utils.SharedPrefUtils
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory

class RegisterActivity : AppCompatActivity() {


    private lateinit var binding: ActivityRegisterBinding

    private lateinit var mainViewModel: MainViewModel

    private lateinit var sharedPrefUtils: SharedPrefUtils

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPrefUtils = SharedPrefUtils(this)

        val mainRepository = MainRepository(AppDatabase(this))
        val viewModelProviderFactory = MainViewModelFactory(application,mainRepository)

        mainViewModel = ViewModelProvider(this,viewModelProviderFactory)[MainViewModel::class.java]

        if (sharedPrefUtils.getUser() != null) {
            goToHome()
        }

        addHospitalAndPoliclinic()

        binding.textViewGoLogin.setOnClickListener {
            goToLogin()
        }

        binding.buttonRegister.setOnClickListener {
            val tcNo = binding.editTextTc.text.toString().toLong()
            val nameAndSurname = binding.editTextNameAndSurname.text.toString()
            val password = binding.editTextPassword.text.toString()

            val user = User(tcNo,nameAndSurname, password)

            mainViewModel.registerUser(user)
            sharedPrefUtils.setUser(user)
            sharedPrefUtils.isRegister = true
            goToHome()

        }


    }

    private fun addHospitalAndPoliclinic() {
        mainViewModel.addHospital(Hospital(1,"Antalya Eğitim ve Araştırma Hastanesi","Antalya"))
        mainViewModel.addHospital(Hospital(2,"AYDIN ATATÜRK DEVLET HASTANESİ","Aydın"))
        mainViewModel.addHospital(Hospital(3,"Marmara Üniversitesi Pendik Eğitim ve Araştırma Hastanesi","İstanbul"))
        mainViewModel.addHospital(Hospital(4,"Karşıyaka Devlet Hastanesi","İzmir"))
        mainViewModel.addHospital(Hospital(5,"Ankara Eğitim ve Araştırma Hastanesi","Ankara"))
        mainViewModel.addHospital(Hospital(6,"Denizli Devlet Hastanesi","Denizli"))
        mainViewModel.addHospital(Hospital(7,"Burdur Devlet Hastanesi","Burdur"))
        mainViewModel.addHospital(Hospital(8,"Balıkesir Devlet Hastanesi","Balıkesir"))
        mainViewModel.addHospital(Hospital(9,"19 Mayıs Devlet Hastanesi","Samsun"))
        mainViewModel.addHospital(Hospital(10,"Fatsa Devlet Hastanesi","Ordu"))

        mainViewModel.addPoliclinic(Policlinic(1,"İç Hastalıkları (Dahiliye)","AYŞEGÜL ZÜMRÜTDAL"))
        mainViewModel.addPoliclinic(Policlinic(2,"Amatem (Alkol ve Madde Bağımlılığı)","CEMAL KARAYAZI"))
        mainViewModel.addPoliclinic(Policlinic(3,"Beyin ve Sinir Cerrahisi","BEHRAM KAYA"))
        mainViewModel.addPoliclinic(Policlinic(4,"Kardiyoloji","RANA MUTTALİP"))
        mainViewModel.addPoliclinic(Policlinic(5,"Nöroloji","KERİM NURİHALİÇİ"))
        mainViewModel.addPoliclinic(Policlinic(6,"Ruh Sağlığı ve Hastalıkları (Psikiyatri)","İREM YALUĞ ULUBİL"))
    }

    private fun goToLogin() {
        val intent = Intent(this,LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun goToHome() {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}