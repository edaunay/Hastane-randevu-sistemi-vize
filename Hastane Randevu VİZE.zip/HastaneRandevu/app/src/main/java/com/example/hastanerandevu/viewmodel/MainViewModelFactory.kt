package com.example.hastanerandevu.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.hastanerandevu.repository.MainRepository

class MainViewModelFactory(val application: Application, private val mainRepository: MainRepository): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(application,mainRepository) as T
    }

}