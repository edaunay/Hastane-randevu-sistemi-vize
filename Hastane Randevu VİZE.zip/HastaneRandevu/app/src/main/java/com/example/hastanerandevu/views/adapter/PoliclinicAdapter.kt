package com.example.hastanerandevu.views.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hastanerandevu.databinding.PoliclinicViewHolderBinding
import com.example.hastanerandevu.model.Policlinic

class PoliclinicAdapter(val policlinicList: List<Policlinic>) : RecyclerView.Adapter<PoliclinicAdapter.ClinicViewHolder>() {

    class ClinicViewHolder(val binding: PoliclinicViewHolderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClinicViewHolder {
        return ClinicViewHolder(
            PoliclinicViewHolderBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    override fun onBindViewHolder(holder: ClinicViewHolder, position: Int) {
        val clinic = policlinicList[position]

        holder.binding.textViewClinicName.text = clinic.clinicName



    }

    override fun getItemCount(): Int {
        return policlinicList.size
    }


}