package com.example.hastanerandevu.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.hastanerandevu.model.Appointment
import com.example.hastanerandevu.model.Blogs
import com.example.hastanerandevu.model.Policlinic
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.User

@Database(entities = [Hospital::class, Policlinic::class,User::class,Appointment::class, Blogs::class], version = 4)
abstract class AppDatabase : RoomDatabase() {
    abstract fun hospitalDao(): HospitalDao
    abstract fun clinicDao(): PoliclinicDao
    abstract fun userDao(): UserDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun blogsDao(): BlogsDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance ?: synchronized(LOCK) {
            instance ?: createDatabase(context).also {
                instance = it
            }
        }

        private fun createDatabase(context: Context) =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "hospital_database"
            ).allowMainThreadQueries().fallbackToDestructiveMigration().build()
    }

}