package com.example.hastanerandevu.views.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hastanerandevu.databinding.PoliclinicSelectViewHolderBinding
import com.example.hastanerandevu.model.Policlinic

class PoliclinicSelectAdapter(val policlinicList: List<Policlinic>) : RecyclerView.Adapter<PoliclinicSelectAdapter.ClinicViewHolder>() {

    lateinit var policlinicSelectListener: PoliclinicSelectListener

    class ClinicViewHolder(val binding: PoliclinicSelectViewHolderBinding) :
        RecyclerView.ViewHolder(binding.root)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClinicViewHolder {
        return ClinicViewHolder(
            PoliclinicSelectViewHolderBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ClinicViewHolder, position: Int) {
        val policlinic = policlinicList[position]

        holder.binding.textViewClinicName.text = policlinic.clinicName
        holder.binding.textViewDoctorName.text = "Doktor: ${policlinic.doctorName}"

        holder.binding.buttonAppointment.setOnClickListener {
            policlinicSelectListener.onSelect(policlinic)
        }


    }

    override fun getItemCount(): Int {
        return policlinicList.size
    }

    interface PoliclinicSelectListener {
        fun onSelect(policlinic: Policlinic)
    }

}