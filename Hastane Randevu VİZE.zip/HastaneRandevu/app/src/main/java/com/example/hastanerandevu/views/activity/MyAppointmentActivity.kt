package com.example.hastanerandevu.views.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.ActivityMyAppointmentBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.utils.SharedPrefUtils
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory
import com.example.hastanerandevu.views.adapter.MyAppointmentAdapter

class MyAppointmentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyAppointmentBinding

    private lateinit var myAppointmentAdapter: MyAppointmentAdapter
    private lateinit var mainViewModel: MainViewModel
    private lateinit var sharedPrefUtils: SharedPrefUtils

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyAppointmentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPrefUtils = SharedPrefUtils(this)

        window.statusBarColor = ContextCompat.getColor(this,R.color.color_red)

        val mainRepository = MainRepository(AppDatabase(this))
        val viewModelProviderFactory = MainViewModelFactory(application, mainRepository)

        mainViewModel = ViewModelProvider(this, viewModelProviderFactory)[MainViewModel::class.java]

        binding.imageViewBack.setOnClickListener {
            finish()
        }

        initRv()




    }

    private fun initRv() {
        myAppointmentAdapter = MyAppointmentAdapter(mainViewModel.myAppointment(sharedPrefUtils.getUser()!!.tcNo))
        binding.recyclerViewMyAppointment.apply {
            layoutManager = LinearLayoutManager(this@MyAppointmentActivity)
            setHasFixedSize(true)
            adapter = myAppointmentAdapter
        }
    }
}