package com.example.hastanerandevu.views.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.hastanerandevu.databinding.MyAppointmentViewHolderBinding
import com.example.hastanerandevu.model.Appointment

class MyAppointmentAdapter(val appointmentList: List<Appointment>) : RecyclerView.Adapter<MyAppointmentAdapter.MyAppointmentViewHolder>() {


    class MyAppointmentViewHolder(val binding: MyAppointmentViewHolderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAppointmentViewHolder {
        return MyAppointmentViewHolder(
            MyAppointmentViewHolderBinding.inflate(
                LayoutInflater.from(parent.context),parent,false
            )
        )
    }

    override fun onBindViewHolder(holder: MyAppointmentViewHolder, position: Int) {
        val appointment = appointmentList[position]

        holder.binding.textViewDate.text = appointment.date
        holder.binding.textViewTime.text = appointment.time
        holder.binding.textViewHospitalName.text = appointment.hospitalName
        holder.binding.textViewDoctorName.text = appointment.doctorName
        holder.binding.textViewPoliclinicName.text = appointment.clinicName
        holder.binding.textViewName.text = appointment.nameAndSurname


    }

    override fun getItemCount(): Int {
        return appointmentList.size
    }


}